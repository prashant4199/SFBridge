#!/bin/bash

/opt/websphere85/cell_Longjump/appserver/java_1.7.1_64/bin/java -cp "*" com.dfs.jose.secret.management.cyberark.sample.CyberArkSample cyberArk.properties 1