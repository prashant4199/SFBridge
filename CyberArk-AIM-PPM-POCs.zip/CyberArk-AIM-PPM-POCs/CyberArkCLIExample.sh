#!/bin/bash

appID=APP-DV-GA-SALESFORCE
virtual_id=VIRT_RMS_DEV

OUT=`/opt/CARKaim/sdk/clipasswordsdk GetPassword -p AppDescs.AppID="${appID}" -p Query="VirtualUsername=$virtual_id" -p FailRequestOnPasswordChange=true -o Password,PassProps.username 2>&1`

if [ $? -eq 0 ]; then
        # Successfully retrieved password and username, consume as needed
        RETURNSTRING=($(echo $OUT | awk -F"," '{print $1,$2}'))
        echo "${RETURNSTRING[1]} ${RETURNSTRING[0]}"

else
        echo "$OUT"  #Unable to retrieve password, prints error
fi