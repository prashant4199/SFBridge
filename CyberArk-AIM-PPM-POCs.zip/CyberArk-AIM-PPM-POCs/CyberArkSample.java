package com.dfs.jose.secret.management.cyberark.sample;

import com.dfs.jose.secret.management.SecretContent;
import com.dfs.jose.secret.management.SecretContentException;
import com.dfs.jose.secret.management.SecretProvider;
import com.dfs.jose.secret.management.SecretRequest;
import com.dfs.jose.secret.management.SecretRequestException;
import com.dfs.jose.secret.management.SecretType;
import com.dfs.jose.secret.management.SecretUnderChangeException;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.TimeUnit;

public class CyberArkSample
{
  public static final String USE_CACHE = "secret.cache";
  public static final String CACHE_TTL = "secret.cache.ttl";
  public static final String TIMER_SHUTDOWN_WAITTIME = "secret.cache.timer.shutdown.waittime";
  private Properties requestProps = new Properties();
  private List<String> responsePropKeys = new ArrayList();
  private SecretType secretType = null;
  private String secretProviderId = null;
  private long cacheTTL = -1L;
  private long cacheRefreshTaskShutdownWaitTime = -1L;
  private boolean useCache = false;
  
  public void loadRunParams(InputStream input)
    throws IOException
  {
    Properties configProps = new Properties();
    configProps.load(input);
    Enumeration<Object> keys = configProps.keys();
    while (keys.hasMoreElements())
    {
      String key = (String)keys.nextElement();
      String value = configProps.getProperty(key);
      if ("RequiredProps".equalsIgnoreCase(key))
      {
        String[] values = value.split(",");
        for (String responsePropKey : values) {
          this.responsePropKeys.add(responsePropKey);
        }
      }
      else if ("secret.type".equalsIgnoreCase(key))
      {
        if (SecretType.PASSWORD.getTypeCode().equalsIgnoreCase(value)) {
          this.secretType = SecretType.PASSWORD;
        } else if (SecretType.ASYMMETRIC_RSA_PRIVATE_KEY.getTypeCode().equalsIgnoreCase(value)) {
          this.secretType = SecretType.ASYMMETRIC_RSA_PRIVATE_KEY;
        } else if (SecretType.SYMMETRIC_AES_KEY.getTypeCode().equalsIgnoreCase(value)) {
          this.secretType = SecretType.SYMMETRIC_AES_KEY;
        } else {
          this.secretType = SecretType.PASSWORD;
        }
      }
      else if ("secret.vault.provider".equalsIgnoreCase(key))
      {
        this.secretProviderId = value;
      }
      else if ("secret.cache.ttl".equalsIgnoreCase(key))
      {
        this.cacheTTL = Long.parseLong(value);
      }
      else if ("secret.cache".equalsIgnoreCase(key))
      {
        this.useCache = Boolean.parseBoolean(value);
      }
      else if ("secret.cache.timer.shutdown.waittime".equalsIgnoreCase(key))
      {
        this.cacheRefreshTaskShutdownWaitTime = Long.parseLong(value);
      }
      else
      {
        this.requestProps.setProperty(key, value);
      }
    }
  }
  
  public SecretProvider newSecretProvider()
  {
    SecretProvider secretProvider = null;
    if (this.cacheTTL > 0L) {
      secretProvider = new SecretProvider(this.secretProviderId, this.cacheTTL);
    } else {
      secretProvider = new SecretProvider(this.secretProviderId);
    }
    return secretProvider;
  }
  
  private static void sleep(long interval)
  {
    try
    {
      TimeUnit.MILLISECONDS.sleep(interval);
    }
    catch (InterruptedException e)
    {
      e.printStackTrace();
    }
  }
  
  public void useSecret(SecretProvider secretProvider, int runCount)
    throws SecretRequestException, SecretContentException, IllegalAccessException, InstantiationException, ClassNotFoundException, SecretUnderChangeException
  {
    boolean testDualAccount = false;
    String query = this.requestProps.getProperty("Query");
    if ((query != null) && 
      (query.contains("VirtualUsername="))) {
      testDualAccount = true;
    }
    if (testDualAccount)
    {
      if (this.useCache)
      {
        if (this.cacheTTL > 0L) {
          call2getSecret(secretProvider, this.requestProps, this.responsePropKeys, this.secretType, this.useCache, false);
        } else {
          System.out.println("If Use Dual Account with cache, then the cache TTL must be set!");
        }
      }
      else {
        call2getSecret(secretProvider, this.requestProps, this.responsePropKeys, this.secretType, false, false);
      }
    }
    else
    {
      long FIRST_RETRY_INTERVAL = 2000L;
      long SECOND_RETRY_INTERVAL = 4000L;
      int numberOfTry = 3;
      long[] RETRY_INTERVAL = { FIRST_RETRY_INTERVAL, SECOND_RETRY_INTERVAL };
      if (this.useCache)
      {
        for (int i = 0; i < numberOfTry; i++) {
          try
          {
            Object secret = call2getSecret(secretProvider, this.requestProps, this.responsePropKeys, this.secretType, this.useCache, true);
            if (secret != null) {
              break;
            }
          }
          catch (SecretUnderChangeException e)
          {
            if (i == numberOfTry - 1) {
              throw e;
            }
            sleep(RETRY_INTERVAL[i]);
            System.out.println("Retry #" + i);
          }
        }
        try
        {
          if (runCount % 4 == 3) {
            throw new SecurityException();
          }
        }
        catch (SecurityException e)
        {
          System.out.println("Update cache because currently cached value is obsolete!");
          call2getSecret(secretProvider, this.requestProps, this.responsePropKeys, this.secretType, this.useCache, true);
        }
      }
      else
      {
        for (int i = 0; i < numberOfTry; i++) {
          try
          {
            Object secret = call2getSecret(secretProvider, this.requestProps, this.responsePropKeys, this.secretType, false, false);
            if (secret != null) {
              break;
            }
          }
          catch (SecretUnderChangeException e)
          {
            if (i == numberOfTry - 1) {
              throw e;
            }
            sleep(RETRY_INTERVAL[i]);
            System.out.println("Retry #" + i);
          }
        }
      }
    }
  }
  
  private Object call2getSecret(SecretProvider secretProvider, Properties requestProps, List<String> responsePropKeys, SecretType type, boolean useCache, boolean updateCache)
    throws SecretRequestException, SecretUnderChangeException, SecretContentException, IllegalAccessException, InstantiationException, ClassNotFoundException
  {
    SecretRequest secretReq = secretProvider.newSecretRequest();
    SecretContent secretCnt = null;
    Object secret = null;
    long startTime = 0L;
    long endTime = 0L;
    startTime = System.currentTimeMillis();
    
    secretCnt = secretReq.getSecret(requestProps, responsePropKeys, this.secretType, useCache, updateCache);
    secret = secretCnt.getSecret();
    endTime = System.currentTimeMillis();
    StringBuilder strBuf = new StringBuilder();
    strBuf.append("secret=").append(secret).append("\n");
    strBuf.append("timestamp=").append(secretCnt.getTimestamp()).append("\n");
    strBuf.append("secretType=").append(secretCnt.getType()).append("\n");
    strBuf.append("secretRequestIdentifier=").append(secretCnt.getId()).append("\n");
    Properties responseProps = secretCnt.getProperties();
    Set<Object> keys = responseProps.keySet();
    for (Object key : keys)
    {
      String value = responseProps.getProperty((String)key);
      strBuf.append(key).append("=").append(value).append("\n");
    }
    long responseTime = endTime - startTime;
    strBuf.append("responseTime=").append(responseTime).append("\n");
    System.out.println(strBuf.toString());
    return secret;
  }
  
  public static void main(String[] args)
  {
    SecretProvider secretProvider = null;
    try
    {
      CyberArkSample sample = new CyberArkSample();
      FileInputStream configInput = new FileInputStream(args[0]);
      sample.loadRunParams(configInput);
      
      secretProvider = sample.newSecretProvider();
      int numberOfSecretUse = Integer.parseInt(args[1]);
      long sleepTime = 1L;
      if ((args.length > 2) && (args[2] != null) && (args[2].length() > 0)) {
        sleepTime = Long.parseLong(args[2]);
      }
      for (int i = 1; i <= numberOfSecretUse; i++)
      {
        sample.useSecret(secretProvider, i);
        sleep(sleepTime);
      }
    }
    catch (Throwable e)
    {
      e.printStackTrace();
    }
    finally
    {
      if (secretProvider != null) {
        secretProvider.destroy();
      }
    }
  }
}
