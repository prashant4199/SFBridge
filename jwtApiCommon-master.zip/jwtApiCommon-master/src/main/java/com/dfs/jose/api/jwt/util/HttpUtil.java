package com.dfs.jose.api.jwt.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.Proxy;
import java.net.URL;
import java.util.Map;
import java.util.Set;

import com.dfs.jose.common.util.Base64Util;


/**
 * @author asubra2, sshyam
 * The utility class provides a set of convenient ways to make HTTP request.
 *
 */
/**
 * @author hchen
 *
 */
public class HttpUtil {

	/**
	 * Use the default connection timeout (2seconds) and default response timeout (5seconds) to make a http Get call to the url provided in the argument
	 * @param urlStr - the endpoint URL to be called by the method
	 * @param proxy - If the HTTP endpoint is outside of the zone of the caller, then the proxy host and port needs to be provided in the Proxy object, e.g. proxy.discoverfinancial.com and port 8080
	 * @param proxyAuthorization If proxy authentication is required, then the authorization string in form of base64(userId:password) needs to be provided.
	 * @return the response body as a string.
	 * @throws IOException if the HTTP response code is not 200.
	 */
	public static String sendHttpGet(String urlStr, Proxy proxy, String proxyAuthorization) throws IOException {
		return sendHttpGet(urlStr, 2000, 5000, proxy, proxyAuthorization);
	}
	
	/**
	 * Used to make a http Get call to the url provided in the argument
	 * @param urlStr - the endpoint URL to be called by the method
	 * @param connectTimeout - the connection timeout value when to make the HTTP connection
	 * @param readTimeout - the response timeout value when wait for the response from the connected endpoint
	 * @param proxy - If the HTTP endpoint is outside of the zone of the caller, then the proxy host and port needs to be provided in the Proxy object, e.g. proxy.discoverfinancial.com and port 8080
	 * @param proxyAuthorization If proxy authentication is required, then the authorization string in form of base64(userId:password) needs to be provided.
	 * @return the response body as a string.
	 * @throws IOException if the HTTP response code is not 200.
	 */
	public static String sendHttpGet(String urlStr, int connectTimeout, int readTimeout, Proxy proxy, String proxyAuthorization) throws IOException {
		HttpURLConnection conn = null;
		BufferedReader rd = null;
		try{
			URL url = new URL(urlStr);
			if( proxy == null ){
				conn = (HttpURLConnection) url.openConnection(Proxy.NO_PROXY);
			}else{
				conn = (HttpURLConnection) url.openConnection(proxy);
			}
			if( proxyAuthorization != null ){
				conn.setRequestProperty("Proxy-Authorization", proxyAuthorization);
			}
			conn.setConnectTimeout(connectTimeout);
			conn.setReadTimeout(readTimeout);
			int responseCode = conn.getResponseCode();
			if (responseCode != HttpURLConnection.HTTP_OK) {
				System.out.println("Failure HTTP response Code:"+responseCode+" for access "+url.toString());
				throw new IOException(conn.getResponseMessage());
			}
			rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
			StringBuilder sb = new StringBuilder();
			String line;
			while ((line = rd.readLine()) != null) {
				sb.append(line);
			}
			return sb.toString();
		}finally{
			if( rd != null ){
				try{
					rd.close();
				}catch(Throwable ex){
					ex.getStackTrace();
				}
			}
			if( conn != null ){
				try{
					conn.disconnect();
				}catch(Throwable ex){
					ex.getStackTrace();
				}
			}
		}
	}

	/**
	 * Use the default connection timeout (2seconds) and default response timeout (5seconds) to make a http Get call to the url provided in the argument
	 * @param urlStr - the endpoint URL to be called by the method
	 * @param headers - the HTTP headers in form of key value pair to be added in the HTTP invocation.
	 * @param proxy - If the HTTP endpoint is outside of the zone of the caller, then the proxy host and port needs to be provided in the Proxy object, e.g. proxy.discoverfinancial.com and port 8080
	 * @param proxyAuthorization If proxy authentication is required, then the authorization string in form of base64(userId:password) needs to be provided.
	 * @return the response body as a string.
	 * @throws IOException if the HTTP response code is not 200.
	 */
	public static String sendHttpGet(String urlStr, Map<String, String> headers, Proxy proxy, String proxyAuthorization) throws IOException {
		return sendHttpGet(urlStr, 2000, 5000, headers, proxy, proxyAuthorization);
	}
	
	/**
	 * Used to make a http Get call to the url provided in the argument
	 * @param urlStr - the endpoint URL to be called by the method
	 * @param connectTimeout - the connection timeout value when to make the HTTP connection
	 * @param readTimeout - the response timeout value when wait for the response from the connected endpoint
	 * @param headers - the HTTP headers in form of key value pair to be added in the HTTP invocation.
	 * @param proxy - If the HTTP endpoint is outside of the zone of the caller, then the proxy host and port needs to be provided in the Proxy object, e.g. proxy.discoverfinancial.com and port 8080
	 * @param proxyAuthorization If proxy authentication is required, then the authorization string in form of base64(userId:password) needs to be provided.
	 * @return the response body as a string.
	 * @throws IOException if the HTTP response code is not 200.
	 */
	public static String sendHttpGet(String urlStr,  int connectTimeout, int readTimeout, Map<String, String> headers, Proxy proxy, String proxyAuthorization) throws IOException {
		HttpURLConnection conn = null;
		BufferedReader rd = null;
		try{
			URL url = new URL(urlStr);
			if( proxy == null ){
				conn = (HttpURLConnection) url.openConnection(Proxy.NO_PROXY);
			}else{
				conn = (HttpURLConnection) url.openConnection(proxy);
			}
			if( proxyAuthorization != null ){
				conn.setRequestProperty("Proxy-Authorization", proxyAuthorization);
			}
			conn.setConnectTimeout(connectTimeout);
			conn.setReadTimeout(readTimeout);
			if( headers != null ){
				Set<String> keys = headers.keySet();
				for(String key:keys){
					conn.addRequestProperty(key, headers.get(key));
				}
			}
			int responseCode = conn.getResponseCode();
			if (responseCode != HttpURLConnection.HTTP_OK) {
				System.out.println("Failure HTTP response Code:"+responseCode+" for access "+url.toString());
				throw new IOException(conn.getResponseMessage());
			}
			rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
			StringBuilder sb = new StringBuilder();
			String line;
			while ((line = rd.readLine()) != null) {
				sb.append(line);
			}
			return sb.toString();
		}finally{
			if( rd != null ){
				try{
					rd.close();
				}catch(Throwable ex){
					ex.getStackTrace();
				}
			}
			if( conn != null ){
				try{
					conn.disconnect();
				}catch(Throwable ex){
					ex.getStackTrace();
				}
			}
		}
	}
	
	/**
	 * Only send HTTP request but ignore response.
	 * @param urlStr - the endpoint URL to be called by the method
	 * @param connectTimeout - the connection timeout value when to make the HTTP connection
	 * @param readTimeout - the response timeout value when wait for the response from the connected endpoint
	 * @param headers - the HTTP headers in form of key value pair to be added in the HTTP invocation.
	 * @param proxy - If the HTTP endpoint is outside of the zone of the caller, then the proxy host and port needs to be provided in the Proxy object, e.g. proxy.discoverfinancial.com and port 8080
	 * @param proxyAuthorization If proxy authentication is required, then the authorization string in form of base64(userId:password) needs to be provided.
	 * @throws IOException if the HTTP response code is not 200.
	 */
	public static void onlySendHttpGet(String urlStr,  int connectTimeout, int readTimeout, Map<String, String> headers, Proxy proxy, String proxyAuthorization) throws IOException {
		HttpURLConnection conn = null;
		InputStream inStream = null;
		try{
			URL url = new URL(urlStr);
			if( proxy == null ){
				conn = (HttpURLConnection) url.openConnection(Proxy.NO_PROXY);
			}else{
				conn = (HttpURLConnection) url.openConnection(proxy);
			}
			if( proxyAuthorization != null ){
				conn.setRequestProperty("Proxy-Authorization", proxyAuthorization);
			}
			conn.setConnectTimeout(connectTimeout);
			conn.setReadTimeout(readTimeout);
			if( headers != null ){
				Set<String> keys = headers.keySet();
				for(String key:keys){
					conn.addRequestProperty(key, headers.get(key));
				}
			}
			inStream = conn.getInputStream();
		}finally{
			if( inStream != null ){
				try{
					inStream.close();
				}catch(Throwable ex){
					ex.getStackTrace();
				}
			}
			if( conn != null ){
				try{
					conn.disconnect();
				}catch(Throwable ex){
					ex.getStackTrace();
				}
			}
		}
	}

	/**
	 * Check if the given string is a HTTP URL, if it is null and malformed, throws IllegalArgumentException exception, otherwise, return the URL string.
	 * The given string can be base 64 encoded.
	 * @param urlStr - the given url string either in form of http(s)://host:port/path or a base 64 encoded string of a URL
	 * @return if it is null and malformed, throws IllegalArgumentException exception
	 */
	public static String toHttpURL(String urlStr){
		if(	 urlStr != null){
			if( !urlStr.matches("https?://.*") ){
				String serviceUrl = null;
				try{
					serviceUrl = new String(Base64Util.decode(urlStr), "UTF-8");
				}catch(Throwable e){
					throw new IllegalArgumentException("Can't parse base64 encoded URL!", e);
				}
				if( serviceUrl != null && serviceUrl.matches("https?://.*") ){
						return serviceUrl;
				}else{
					throw new IllegalArgumentException("Malformated HTTP URL (Base64 Encoded)!");
				}
			}else{
				return urlStr;
			}
		}else{
			throw new IllegalArgumentException("Malformated HTTP URL (URL is not provided!)");
		}
	}
	
	public static String sendHttp(String urlStr,  int connectTimeout, int readTimeout, Map<String, String> headers, String method, String reqBody, Proxy proxy, String proxyAuthorization) throws IOException {
		HttpURLConnection conn = null;
		BufferedReader rd = null;
		OutputStreamWriter out = null;
		try{
			URL url = new URL(urlStr);
			if( proxy == null ){
				conn = (HttpURLConnection) url.openConnection(Proxy.NO_PROXY);
			}else{
				conn = (HttpURLConnection) url.openConnection(proxy);
			}
			if( proxyAuthorization != null ){
				conn.setRequestProperty("Proxy-Authorization", proxyAuthorization);
			}
			conn.setRequestMethod(method);
			conn.setConnectTimeout(connectTimeout);
			conn.setReadTimeout(readTimeout);
			if( headers != null ){
				Set<String> keys = headers.keySet();
				for(String key:keys){
					conn.addRequestProperty(key, headers.get(key));
				}
			}
			if( reqBody != null && !reqBody.isEmpty()){
				out = new OutputStreamWriter(conn.getOutputStream());
				out.write(reqBody);
			}
			int responseCode = conn.getResponseCode();
			if (responseCode != HttpURLConnection.HTTP_OK) {
				System.out.println("Failure HTTP response Code:"+responseCode+" for access "+url.toString());
				throw new IOException(conn.getResponseMessage());
			}
			rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
			StringBuilder sb = new StringBuilder();
			String line;
			while ((line = rd.readLine()) != null) {
				sb.append(line);
			}
			return sb.toString();
		}finally{
			if( out != null ){
				try{
					out.close();
				}catch(Throwable e){
					e.printStackTrace();
				}
			}
			if( rd != null ){
				try{
					rd.close();
				}catch(Throwable ex){
					ex.getStackTrace();
				}
			}
			if( conn != null ){
				try{
					conn.disconnect();
				}catch(Throwable ex){
					ex.getStackTrace();
				}
			}
		}
	}

}
