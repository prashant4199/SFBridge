package com.dfs.jose.apigateway.jwt;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.SignatureException;
import java.security.UnrecoverableEntryException;
import java.security.UnrecoverableKeyException;
import java.security.cert.Certificate;
import java.security.cert.CertificateException;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.node.ArrayNode;
import org.codehaus.jackson.node.JsonNodeFactory;
import org.codehaus.jackson.node.ObjectNode;

import com.dfs.jose.alg.HMAC;
import com.dfs.jose.alg.RSAwithSHA;
import com.dfs.jose.common.util.Base64Util;
import com.dfs.jose.common.util.HexUtil;
import com.dfs.jose.jwt.JWTAlgorithm;
import com.dfs.jose.jwt.JWTParts;
import com.dfs.jose.key.KeyUtil;

/**
 * class ApiGatewayJWTGenerator is a fundational class used to generate JWT tokens of type HS256 and RS256.
 */
public class ApiGatewayJWTGenerator {

	public static final long DEFAULT_TTL = 3600L;
	private String appId;
	private String issuer;
	private String subject;
	private long expiresAt;
	private long timeToLive = -1;
	private long issuedAt = -1;
	private byte[] secret;
	private PrivateKey privateKey;

	/**
	 * default constructor
	 */
	public ApiGatewayJWTGenerator() {
		super();
	}

	/**
	 * Create a JWT token generator for algorithm HS256
	 * @param secret The secret used to generate the token
	 * @param expiresAt when the token will expires in unix timestamp format in seconds.
	 * @param issuer the issuer of the token
	 * @param subject the subject of the token claims
	 */
	public ApiGatewayJWTGenerator(byte[] secret, long expiresAt, String issuer, String subject) {
		super();
		this.secret = secret;
		this.issuer = issuer;
		this.subject = subject;
		this.expiresAt = expiresAt;
	}

	/**
	 * Create a JWT token generator for algorithm RS256
	 * @param privateKey the private key used to generate the token
	 * @param expiresAt when the token will expires in unix timestamp format in seconds.
	 * @param issuer the issuer of the token
	 * @param subject the subject of the token claims
	 */
	public ApiGatewayJWTGenerator(PrivateKey privateKey, long expiresAt, String issuer, String subject) {
		super();
		this.privateKey = privateKey;
		this.issuer = issuer;
		this.subject = subject;
		this.expiresAt = expiresAt;
	}
	
	/**
	 * construct the ApiGatewayJWTGenerator object by using the given parameter.
	 * @param secret the secret to be used in HS256 signature algorithm (can be null if the generated JWT token is not HS256)
	 * @param privateKey the private key used to generate the RS256 token (can be null if the generated JWT token is not RS256)
	 * @param issuer the issuer of the token
	 * @param expiresAt when the token will expires in unix timestamp format in seconds.
	 * 
	 * @deprecated Will not supported in later release. The constructor is only used for backward compatiblity of the existing application. New application should not use the constructor.
	 */
	public ApiGatewayJWTGenerator(byte[] secret, PrivateKey privateKey, String issuer, long expiresAt) {
		super();
        if ( (secret == null || secret.length == 0) && (privateKey==null) ) {
            throw new IllegalArgumentException("Secret or privateKey cannot be both null or not be given!");
        }
        if (issuer == null || "".equals(issuer)) {
            throw new IllegalArgumentException("Issuer cannot be null or empty!");
        }
        if( expiresAt <= 0 ){
            throw new IllegalArgumentException("Token expiration time must be larger than 0!");
        }
        this.secret = secret;
        this.privateKey = privateKey;
		this.issuer = issuer;
		this.expiresAt = expiresAt;
	}
	
	/**
	 * construct the ApiGatewayJWTGenerator object by using the given parameter.
	 * @param secret the secret to be used in HS256 signature algorithm (can be null if the generated JWT token is not HS256)
	 * @param privateKey the private key used to generate the RS256 token (can be null if the generated JWT token is not RS256)
	 * @param issuer the issuer of the token
	 * @deprecated Will not supported in later release. The constructor is only used for backward compatiblity of the existing application. New application should not use the constructor.
	 */
	public ApiGatewayJWTGenerator(byte[] secret, PrivateKey privateKey, String issuer) {
		super();
        if ( (secret == null || secret.length == 0) && (privateKey==null) ) {
            throw new IllegalArgumentException("Secret or privateKey cannot be both null or not be given!");
        }
        if (issuer == null || "".equals(issuer)) {
            throw new IllegalArgumentException("Issuer cannot be null or empty!");
        }
        this.secret = secret;
        this.privateKey = privateKey;
		this.issuer = issuer;
	}
	
	/**
	 * @return the application id or api key which is the JWT token claims' subject field
	 */
	public String getApplicationId() {
		return appId;
	}


	/**
	 * @param appId the application id or api key which is the JWT token claims' subject field
	 */
	public void setApplicationId(String appId) {
		this.appId = appId;
	}

	/**
	 * @return JWT token claims's issuer field
	 */
	public String getIssuer() {
		return issuer;
	}

	/**
	 * @param issuer JWT token claims's issuer field
	 */
	public void setIssuer(String issuer) {
		this.issuer = issuer;
	}

	/**
	 * @return JWT token claims's subject field
	 */
	public String getSubject() {
		return subject;
	}

	/**
	 * @param subject JWT token claims's subject field
	 */
	public void setSubject(String subject) {
		this.subject = subject;
	}

	/**
	 * @return the JWT Token life time in seconds
	 */
	public long getTimeToLive() {
		return timeToLive;
	}

	/**
	 * @param timeToLive the JWT Token life time in seconds
	 */
	public void setTimeToLive(long timeToLive) {
		this.timeToLive = timeToLive;
	}

	/**
	 * @return the JWT token claims' issused at field
	 */
	public long getIssuedAt() {
		return issuedAt;
	}

	/**
	 * Old Function is
	 * <pre>
	 * <code>
	public void setIssuedAt(long iatOffset){
		this.expiresAt = (System.currentTimeMillis())/1000L+iatOffset;
	}
	</code>
	is not right. It actually sets expiration time based on the offset. 
	</pre>
	 */
	/**
	 * @param issuedAt the JWT token claims' issused at field 
	 */
	public void setIssuedAt(long issuedAt) {
		this.issuedAt = issuedAt;
	}

	/**
	 * @return the secret bytes which is used to generate HS256 JWT token
	 */
	public byte[] getSecret() {
		return secret;
	}

	/**
	 * @param secret the secret bytes which is used to generate HS256 JWT token
	 */
	public void setSecret(byte[] secret) {
		this.secret = secret;
	}

	/**
	 * @return the private key object which is used to generate RS256 JWT token
	 */
	public PrivateKey getPrivateKey() {
		return privateKey;
	}

	/**
	 * @param privateKey the private key object which is used to generate RS256 JWT token
	 */
	public void setPrivateKey(PrivateKey privateKey) {
		this.privateKey = privateKey;
	}
	
	/**
	 * @return the JWT token claims's expiration field, i.e. when the JWT token will be expired in seconds.
	 */
	public long getExpiresAt() {
		return expiresAt;
	}

	/**
	 * @param expiresAt the JWT token claims's expiration field, i.e. when the JWT token will be expired in seconds.
	 */
	public void setExpiresAt(long expiresAt) {
		this.expiresAt = expiresAt;
	}

	/**
	 * generate a JWT token
	 * @param alg only supported JWT algorithms are HS256 and RS256.
	 * @return The target JWT token in serialization form.
	 * @throws SignatureException if generating the JWT token failed.
	 * @deprecated Will not supported in later release. The function is only used for backward compatiblity of the existing application. New application should not use the function.
	 */
	public String execute(String alg) throws SignatureException{
		ObjectNode extraClaims = null;
		return execute(alg, extraClaims);
	}

	/**
	 * generate a JWT token
	 * @param alg only supported JWT algorithms are HS256 and RS256.
	 * @param nonRegisteredClaims additional JWT token claims' fields not provided in the constructor of the class
	 * @return The target JWT token in serialization form.
	 * @throws SignatureException if generating the JWT token failed.
	 */
	public String execute(String alg, ObjectNode nonRegisteredClaims) throws SignatureException{
		return execute(alg, null, nonRegisteredClaims);
	}

	/**
x	 * generate a JWT token
	 * @param alg only supported JWT algorithms are HS256 and RS256.
	 * @param nonRegisteredHeaders additional JWT token headers' fields not provided in the constructor of the class
	 * @param nonRegisteredClaims additional JWT token claims' fields not provided in the constructor of the class
	 * @return The target JWT token in serialization form.
	 * @throws SignatureException if generating the JWT token failed.
	 */
	public String execute(String alg, ObjectNode nonRegisteredHeaders, ObjectNode nonRegisteredClaims) throws SignatureException{
		try {
			if( alg.equals( "HS256" ) ){
				if( (secret == null || secret.length == 0) ){
		            throw new IllegalArgumentException("Secret cannot be both null or not be given!");
				}
			}else if( alg.equals( "RS256") ){
		        if ( privateKey==null ) {
		            throw new IllegalArgumentException("Private key cannot be both null or not be given!");
		        }
			}else{
				throw new IllegalStateException("Unsupported JWT algorithm!");
			}
	        if (issuer == null || "".equals(issuer)) {
	            throw new IllegalArgumentException("Issuer cannot be null or empty!");
	        }
	        if (subject == null || "".equals(subject)) {
	            throw new IllegalArgumentException("Subject cannot be null or empty!");
	        }
	        if( expiresAt <= 0 ){
		        if( timeToLive <= 0 ){
		            throw new IllegalArgumentException("Token time to live or expiration time must be larger than 0!");
		        }
	        }

	        //Set JWT Header
			ObjectNode jwtHeader = JsonNodeFactory.instance.objectNode();
			jwtHeader.put("alg", alg); //"alg" is "HS256" or "RS256"
			if( nonRegisteredHeaders != null ){
				jwtHeader.putAll(nonRegisteredHeaders);
			}
			String b64UrlEncodedHeader = Base64Util.urlSafeEncode(jwtHeader.toString().getBytes("UTF-8"));
			//Set JWT Claims
			ObjectNode jwtClaims = JsonNodeFactory.instance.objectNode();
			jwtClaims.put("iss", issuer);
			jwtClaims.put("sub", subject);
			if( expiresAt > 0 ){
				if( issuedAt > 0 ){
					jwtClaims.put("exp", expiresAt);
					jwtClaims.put("iat", issuedAt);
				}else{
					jwtClaims.put("exp", expiresAt); //only set exp, iat is unknown
				}
			}else{
				if( timeToLive > 0 ){
					if( issuedAt > 0 ){
						jwtClaims.put("exp", issuedAt + timeToLive);
						jwtClaims.put("iat", issuedAt);
					}else{
						long currentTime = (System.currentTimeMillis())/1000L; 
						jwtClaims.put("exp", currentTime + timeToLive);
						jwtClaims.put("iat", currentTime);
					}
				}else{//this branch should never be reached because in the implementation either exp or ttl must be provided.
					if( issuedAt > 0 ){
						jwtClaims.put("exp", issuedAt + DEFAULT_TTL);
						jwtClaims.put("iat", issuedAt);
					}else{
						long currentTime = (System.currentTimeMillis())/1000L; 
						jwtClaims.put("exp", currentTime + DEFAULT_TTL);
						jwtClaims.put("iat", currentTime);
					}
				}
			}
//			if( expiresAt > 0 ){
//				jwtClaims.put("exp", expiresAt);
//			}else{
//				jwtClaims.put("exp", expirationTime());
//			}
//			if( issuedAt > 0 ){
//				jwtClaims.put("iat", issuedAt);
//			}else{
//				//Generate iat only if issuedAt is not provided and expiresAt is not provided.
//				if( expiresAt <= 0 ){
//					jwtClaims.put("iat", (System.currentTimeMillis())/1000L);
//				}
//			}
			//jwtClaims.put("sub", subject);
			if( nonRegisteredClaims != null ){
				jwtClaims.putAll(nonRegisteredClaims);
			}
			//System.out.println(jwtClaims.toString());
			String b64UrlEncodedClaims = Base64Util.urlSafeEncode(jwtClaims.toString().getBytes("UTF-8"));
			// Generate signature
			String signingStr = b64UrlEncodedHeader+"."+b64UrlEncodedClaims;
			byte[] sig = null;
			if( alg.equals( "HS256" ) ){
				sig = HMAC.execute(JWTAlgorithm.HS256.getValue(), secret, signingStr.getBytes("UTF-8"));
			}else if( alg.equals( "RS256") ){
				sig = RSAwithSHA.sign(JWTAlgorithm.RS256.getValue(), privateKey, signingStr.getBytes("UTF-8"));
			}else{
				throw new IllegalStateException("Unsupported JWT algorithm!");
			}
	    	String b64UrlEncodedSignature = Base64Util.urlSafeEncode(sig);
	    	JWTParts parts = new JWTParts(b64UrlEncodedHeader, b64UrlEncodedClaims, b64UrlEncodedSignature);
	    	return parts.getSerializedPresentation();
		} catch (UnsupportedEncodingException e) {
			throw new IllegalStateException("Generating JWT Header fails!", e);
		}
	}

	/**
	 * generate a JWT token
	 * @param alg only supported JWT algorithms are HS256 and RS256.
	 * @param nonRegisteredClaims key and value pair formated claims are not provided when the generator object is constructed. If not extra claims, set it to null.
	 * @return The target JWT token in serialization form.
	 * @throws SignatureException if generating the JWT token failed.
	 */
	public String execute(String alg, Map<String, String> nonRegisteredClaims) throws SignatureException{
		ObjectNode extraFields = null;
		if( nonRegisteredClaims != null ){
			extraFields = JsonNodeFactory.instance.objectNode();
		 	Set<String> keys = nonRegisteredClaims.keySet();
		 	for(String key:keys){
		 		extraFields.put(key, nonRegisteredClaims.get(key));
		 	}
		}
		return execute(alg, extraFields);
	}

//	/**
//	 * @return JWT token expiration time based on given token time to live and issued at time. If the issued at time is not given, use the system current time.
//	 */
//	private long expirationTime(){
//		if( issuedAt <= 0 ){
//			return (System.currentTimeMillis())/1000L+timeToLive;
//		}else{
//			return issuedAt + timeToLive;
//		}
//	}

	/**
	 * Calculate the JWT token expiration time based on the given token's life time and current system time in seconds 
	 * @param ttl the token's life time in seconds
	 * @return the JWT token expiration time based on the given token's life time and current system time in seconds
	 */
	public static long expirationTime(long ttl){
		long expirationTime = (System.currentTimeMillis())/1000L+ttl;
		return expirationTime;
	}
	
	public static String generateJTI(byte[] secret, long expirationTime) throws UnsupportedEncodingException, RuntimeException{
		UUID uuid = UUID.randomUUID();
		String tokenId = uuid.toString()+"."+String.valueOf(expirationTime);
		String signature = Base64Util.urlSafeEncode(HMAC.execute("HmacSHA256", secret, tokenId.getBytes("UTF-8")));
		return Base64Util.urlSafeEncode(tokenId.getBytes("UTF-8"))+"."+signature;
	}
	
	/**
	 * The method is only used to test the functions of the class
	 * Test Steps:
	 * Set the secret in the secret variable
	 * secret is used for HS256 JWT token and must be provided.
	 * Generate JWT Token expiration time by providing expiration interval to function expirationTime();
	 * Generate ApiGatewayJWTGenerator object by providing issuer string ("apisdev.discover.com"), subject string ("APP-KEY-FORTEST"), and expiration time.
	 * Call ApiGatewayJWTGenerator object's execute() method by providing JWT token Algorithm HS256.
	 */
	public static void generateHS256Test(){
		ApiGatewayJWTGenerator gen;
		try {
			//117D2C34A366BF890C730641E6CECF6F117D2C34A366BF890C730641E6CECF6F
			byte[] secret = "43f7b7b91df847ab973de21bcbdb8fea".getBytes("UTF-8");
			long expirationTime = expirationTime(3600L);
			//expirationTime = 1408146532L;
			//			gen = new ApiGatewayJWTGenerator(secret, null, "issuer", "APP-KEY-FORTEST2", expirationTime);
			//gen = new ApiGatewayJWTGenerator(secret, null, "apisdev.discover.com", expirationTime);
			gen = new ApiGatewayJWTGenerator(secret, expirationTime, "apisdev.discover.com", "l7xx412a34d4e7e9443d8762195d89ecf17b");
			ObjectNode extraFields = JsonNodeFactory.instance.objectNode();
			extraFields.put("scopes", "scope1 scope2");
			//extraFields.put("iat", System.currentTimeMillis()/1000L);
			String jti = ApiGatewayJWTGenerator.generateJTI(secret, expirationTime);
			String[] jtiParts = jti.split("\\.");
			System.out.println("jtiPart1="+(new String(Base64Util.urlSafeDecode(jtiParts[0]), "UTF-8")));
			extraFields.put("jti", jti);
			extraFields.put("env", "DEV");
			ObjectMapper mapper = new ObjectMapper();
			ArrayNode arrayNode = mapper.createArrayNode();
			arrayNode.add("gwsandbox.discover.com");
			arrayNode.add("gateway.discover.com");
			extraFields.put("aud", arrayNode);
			String jwt = gen.execute("HS256", extraFields);
			System.out.println("Token:"+jwt);
			System.out.println("Token Headers ="+ApiGatewayJWTValidator.getJWTHeader(ApiGatewayJWTValidator.getJWTParts(jwt)));
			System.out.println("Token Claims ="+ApiGatewayJWTValidator.getClaims(ApiGatewayJWTValidator.getJWTParts(jwt)));
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		} catch (SignatureException e) {
			e.printStackTrace();
		}
	}

	/**
	 * The method is only used to test the functions of the class
	 * Test Steps:
	 * Replace the real DFS JWT Issuer private key store file path to variable certFile.
	 * Private Key is used to generate RS256 JWT token and must be provided. Load the private key by providing private key store password and key password.
	 * Generate JWT Token expiration time by providing expiration interval to function expirationTime();
	 * Generate ApiGatewayJWTGenerator object by providing issuer string ("apisdev.discover.com"), subject string ("APP-KEY-FORTEST"), and expiration time.
	 * Call ApiGatewayJWTGenerator object by providing JWT token Algorithm RS256.
	 */
	public static void generateRS256Test(){
		ApiGatewayJWTGenerator gen;
		//String keyStoreFile = "C:\\Users\\hchen\\Documents\\tasks\\openApi\\layer7\\test\\signPrivateKey.p12";
		String keyStoreFile = "C:\\Users\\hchen\\Documents\\tasks\\soap\\security\\wks\\api-jwt\\dfsJWTIssuerPrivateKey.p12";
		KeyStore keystore;
		try {
			byte[] secret = "43f7b7b91df847ab973de21bcbdb8fea".getBytes("UTF-8");
			keystore = KeyStore.getInstance("PKCS12");
			keystore.load(new FileInputStream(keyStoreFile), "password".toCharArray());
			PrivateKey privateKey = (PrivateKey)keystore.getKey("dfs.jwt.dev.issuer", "password".toCharArray());
			String certKeystore = "C:\\Users\\hchen\\Documents\\tasks\\soap\\security\\wks\\api-jwt\\keystore.jceks";
			Certificate cert = KeyUtil.loadCertificate("JCEKS", certKeystore, "password", "dfs.jwt.dev.issuer");
			System.out.println(HexUtil.encode(KeyUtil.getCertificateFingerprints(cert)));
			String b64UrlCertFingerPrint = Base64Util.encode(KeyUtil.getCertificateFingerprints(cert));
			System.out.println(b64UrlCertFingerPrint);
			long expirationTime = expirationTime(7200L);
			//expirationTime = 1408146532L;
			gen = new ApiGatewayJWTGenerator(privateKey, expirationTime, "apisdev.discover.com", "l7xx412a34d4e7e9443d8762195d89ecf17b");
			ObjectNode extraFields = JsonNodeFactory.instance.objectNode();
			extraFields.put("scopes", "scope1 scope2");
			//extraFields.put("iat", System.currentTimeMillis()/1000L);
			String jti = ApiGatewayJWTGenerator.generateJTI(secret, expirationTime);
			String[] jtiParts = jti.split("\\.");
			System.out.println("jtiPart1="+(new String(Base64Util.urlSafeDecode(jtiParts[0]), "UTF-8")));
			extraFields.put("jti", jti);
			extraFields.put("env", "DEV");
			extraFields.put("emptyField", "");
//			ObjectMapper mapper = new ObjectMapper();
//			ArrayNode arrayNode = mapper.createArrayNode();
//			arrayNode.add("gwsandbox.discover.com");
//			arrayNode.add("gateway.discover.com");
//			extraFields.put("aud", arrayNode);
			extraFields.put("aud", "PROD");
			//x5t#S256 
			ObjectNode extraHeaders = JsonNodeFactory.instance.objectNode();
			extraHeaders.put("x5t#S256", b64UrlCertFingerPrint);			
			String jwt = gen.execute("RS256", extraHeaders, extraFields);
			System.out.println("Token:"+jwt);
			System.out.println("Token Headers ="+ApiGatewayJWTValidator.getJWTHeader(ApiGatewayJWTValidator.getJWTParts(jwt)));
			System.out.println("Token Claims ="+ApiGatewayJWTValidator.getClaims(ApiGatewayJWTValidator.getJWTParts(jwt)));
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		} catch (KeyStoreException e) {
			e.printStackTrace();
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		} catch (CertificateException e) {
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (UnrecoverableKeyException e) {
			e.printStackTrace();
		} catch (SignatureException e) {
			e.printStackTrace();
		} catch (UnrecoverableEntryException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Only used to test the functions of the class
	 * @param args
	 * Test Steps
	 * If try to create HS256 token, run generateHS256() method; if try to create RS256 token, run generateRS256() method.
	 */
	public static void main(String[] args) {
		generateHS256Test();
		generateRS256Test();
	}

}
