package com.dfs.jose.api.jwt.util;

/**
 *The class presents a X509 certificate content in base64 encoded form. (i.e. PEM)
 *
 */
public class X509CertContent {
	private String base64;

	
	/**
	 * default constructor
	 */
	public X509CertContent() {
		super();
	}

	/**
	 * @param base64 a string presents a X509 certificate content in base64 encoded form
	 */
	public X509CertContent(String base64) {
		super();
		this.base64 = base64;
	}

	/**
	 * @return a string presents a X509 certificate content in base64 encoded form
	 */
	public String getBase64() {
		return base64;
	}

	/**
	 * @param base64 a string presents a X509 certificate content in base64 encoded form
	 */
	public void setBase64(String base64) {
		this.base64 = base64;
	}
	
}
