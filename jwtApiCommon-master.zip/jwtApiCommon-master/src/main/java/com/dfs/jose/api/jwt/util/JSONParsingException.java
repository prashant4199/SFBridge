package com.dfs.jose.api.jwt.util;

/**
 * The exception is used to present errors when serialize or derialize a json object.
 *
 */
public class JSONParsingException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * default constructor
	 */
	public JSONParsingException() {
	}

	/**
	 * @param message - exception error message
	 */
	public JSONParsingException(String message) {
		super(message);
	}

	/**
	 * @param cause - the root cause of the exception
	 */
	public JSONParsingException(Throwable cause) {
		super(cause);
	}

	/**
	 * @param message - exception error message
	 * @param cause - the root cause of the exception
	 */
	public JSONParsingException(String message, Throwable cause) {
		super(message, cause);
	}

}
