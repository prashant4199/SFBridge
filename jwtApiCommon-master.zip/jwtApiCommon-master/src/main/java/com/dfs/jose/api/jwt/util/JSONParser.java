/**
 * 
 */
package com.dfs.jose.api.jwt.util;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;

//import com.dfs.rewards.redemption.rs.AccountInformation;

/**
 * The utility class serialize a java object into a json string or deserialize a json string into a java object.
 *
 */
public class JSONParser {

	/**
	 *  deserialize a json string into a java object
	 * @param <T> - the java class name into which a given json string is deserialized.
	 * @param jsonStr - the json string to be deserialized.
	 * @param t - the java class into which a given json string is deserialized.
	 * @return the corresponding java object representing the json string
	 * @throws JSONParsingException if the json string can't be parsed.
	 */
	public static <T> T toJava(String jsonStr, Class<T> t) throws JSONParsingException{
		ObjectMapper objMapper = new ObjectMapper();
		T obj;
		try {
			obj = objMapper.readValue(jsonStr, t);
			return obj;
		} catch (JsonParseException e) {
			throw new JSONParsingException("JSON String to java object parsing failed!", e);
		} catch (JsonMappingException e) {
			throw new JSONParsingException("JSON String to java object parsing failed!", e);
		} catch (IOException e) {
			throw new JSONParsingException("JSON String to java object parsing failed!", e);
		}
	}

	/**
	 * serialize a java object into a json string
	 * @param obj - the given java object to be serialized.
	 * @return the json string representing the given java object.
	 * @throws JSONParsingException if the java object can't be serialized into a json string.
	 */
	public static String toJSON(Object obj) throws JSONParsingException{
		ObjectMapper objMapper = new ObjectMapper();
		try {
			String jsonStr = objMapper.writeValueAsString(obj);
			return jsonStr;
		} catch (JsonParseException e) {
			throw new JSONParsingException("JSON String to java object parsing failed!", e);
		} catch (JsonMappingException e) {
			throw new JSONParsingException("JSON String to java object parsing failed!", e);
		} catch (IOException e) {
			throw new JSONParsingException("JSON String to java object parsing failed!", e);
		}
		
	}
	
	/**
	 * default constructor
	 */
	/**
	 * 
	 */
	private JSONParser() {
	}

	/**
	 * Load a json object string from a file
	 * @param jsonFile - the json file fully qualified path.
	 * @return the json object string contained in the given file
	 * @throws IOException if the json object string can't be loaded from the given file.
	 */
	public static String loadContentFromJsonFile(String jsonFile) throws IOException {
		StringBuilder strBuf = new StringBuilder();
		BufferedReader reader = null;
		try {
			reader = new BufferedReader(new FileReader(jsonFile));
			String line = reader.readLine();
			while (line != null) {
				strBuf.append(line).append("\n");
				line = reader.readLine();
			}
			String configContent = strBuf.toString();
			if( configContent == null || configContent.isEmpty() ){
				throw new IOException("Loading json File Content failed!");	
			}
			return configContent;
		} finally {
			try {
				if (reader != null) {
					reader.close();
				}
			} catch (Throwable e) {
			}
		}
	}

	/**
	 * @param args
	 */
//	public static void main(String[] args) {
//		String jsonStr = "{\"accountNumber\":\"6011004033975323\",\"expiryDate\":\"2013-11\"}";
//		try {
//			AccountInformation acctInfo = toJava(jsonStr, AccountInformation.class);
//			System.out.println("accountNumber="+acctInfo.getAccountNumber());
//			System.out.println("expiryDate="+acctInfo.getExpiryDate());
//		} catch (JSONParsingException e) {
//			e.printStackTrace();
//		}
//
//	}

}
