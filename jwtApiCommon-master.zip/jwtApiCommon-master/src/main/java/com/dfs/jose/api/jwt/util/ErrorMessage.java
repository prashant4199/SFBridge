/**
 * 
 */
package com.dfs.jose.api.jwt.util;

/**
 * The class is used to define an error message.
 *
 */
public class ErrorMessage {
	protected String error;
	protected String error_description;
	
	/**
	 * Default constructor
	 */
	public ErrorMessage() {
	}

	/**
	 * Construct an error message by using error code and error description
	 * @param error - error code defined specifically for this kind of error
	 * @param error_description - describe what's the error is.
	 */
	public ErrorMessage(String error, String error_description) {
		super();
		this.error = error;
		this.error_description = error_description;
	}

	/**
	 * @return error code
	 */
	public String getError() {
		return error;
	}

	/**
	 * set error code of the error message
	 * @param error - error code
	 */
	public void setError(String error) {
		this.error = error;
	}

	/**
	 * @return the error description
	 */
	public String getError_description() {
		return error_description;
	}

	/**
	 * Set the error description of the error message
	 * @param error_description - error description
	 */
	public void setError_description(String error_description) {
		this.error_description = error_description;
	}

	
	/* (non-Javadoc)
	 * Return JSON presentation of the ErrorMessage object
	 */
	@Override
	public String toString() {
		StringBuilder strBuf = new StringBuilder();
		strBuf.append("{\"error\":\"").append(error).append("\",\"error_description\":\"").append(error_description).append("\"}");
		return strBuf.toString();
	}

}
