package com.dfs.config.pcf;

public interface SpringConfig {
	public String getProperty(String name);
}
