package com.dfs.config.pcf;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class PCFAppConfig {

	private final static Logger logger = LoggerFactory.getLogger(PCFAppConfig.class);
	
	private static final String ENV_PROP_USE_SPRING_CFG = "use_spring_cfg";
	private static final String CLASS_NAME_SPRING_CFG = "com.dfs.spring.config.SpringConfigImplement";
	
	private static SpringConfig springCfg = null;
	
	static{
		if( logger.isDebugEnabled() ){
			logger.debug("Enter PCFAppConfig class static block!");
		}
		try{
			String useSpringCfg = System.getenv(ENV_PROP_USE_SPRING_CFG);
			if( !"FALSE".equalsIgnoreCase(useSpringCfg) ){
				Class<?> springCfgClass = Class.forName(CLASS_NAME_SPRING_CFG);
				springCfg = (SpringConfig)springCfgClass.newInstance();
				if( logger.isDebugEnabled() ){
					logger.debug(CLASS_NAME_SPRING_CFG+" is instantiated!"+springCfg);
				}
			}else{
				if( logger.isDebugEnabled() ){
					logger.debug(CLASS_NAME_SPRING_CFG+" is not instantiated!");
				}				
			}
//			Class<?> springCfgClass = Class.forName(CLASS_NAME_SPRING_CFG);
//			springCfg = (SpringConfig)springCfgClass.newInstance();
		}catch(Throwable e){
			String mesg = "Spring Configuration Support can't be enabled!";
			if( logger.isDebugEnabled() ){
				logger.debug(mesg, e);
			}
			if( logger.isInfoEnabled() ){
				logger.info(mesg);
			}
		}
	}
	
	public static String getProperty(String name){
		if( springCfg != null ){
			if( logger.isDebugEnabled() ){
				logger.debug("Using spring config to retrieve configuration properties!");
			}
			String value = ((SpringConfig)springCfg  ).getProperty(name);
			if( logger.isDebugEnabled() ){
				String logFirst4Value = value;
				String logLast4Value = value;
				if( value != null && value.length() > 4 ){
					logFirst4Value = value.substring(0, 4);
					logLast4Value = value.substring(value.length()-4);
				}
				StringBuffer mesgBuf = new StringBuffer("Property ");
				mesgBuf.append(name).append("=").append(logFirst4Value).append("...").append(logLast4Value).append(" is retrieved from spring configuration!\n");
				logger.debug(mesgBuf.toString());
			}
			return value; 
		}else{
			if( logger.isDebugEnabled() ){
				logger.debug("Using container environment variable to retrieve configuration properties!");
			}
			String value = System.getenv(name);
			if( logger.isDebugEnabled() ){
				String logFirst4Value = value;
				String logLast4Value = value;
				if( value != null && value.length() > 4 ){
					logFirst4Value = value.substring(0, 4);
					logLast4Value = value.substring(value.length()-4);
				}
				StringBuffer mesgBuf = new StringBuffer("Property ");
				mesgBuf.append(name).append("=").append(logFirst4Value).append("...").append(logLast4Value).append(" is retrieved from container environment variable!\n");
				logger.debug(mesgBuf.toString());
			}
			return value;
		}
		
	}
}
