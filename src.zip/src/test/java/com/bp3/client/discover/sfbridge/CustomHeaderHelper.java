package com.bp3.client.discover.sfbridge;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;

public class CustomHeaderHelper extends HttpServletRequestWrapper {
    private Map<String, String> headerMap;

    public CustomHeaderHelper(final HttpServletRequest request) {
        super(request);
        headerMap = new HashMap<String, String>();
    }

    public void addHeader(final String name, final String value) {
        headerMap.put(name, new String(value));
    }

    public Enumeration getHeaderNames() {
        HttpServletRequest request = (HttpServletRequest) getRequest();
        List list = new ArrayList();
        for (Enumeration e = request.getHeaderNames(); e.hasMoreElements();) {
            list.add(e.nextElement().toString());
        }
        for (Iterator i = headerMap.keySet().iterator(); i.hasNext();) {
            list.add(i.next());
        }
        return Collections.enumeration(list);
    }

    public String getHeader(final String name) {
        Object value = headerMap.get("" + name);
        if (value != null) {
            return value.toString();
        } else {
            return ((HttpServletRequest) getRequest()).getHeader(name);
        }
    }
}
