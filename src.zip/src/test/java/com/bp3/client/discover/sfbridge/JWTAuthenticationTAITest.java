package com.bp3.client.discover.sfbridge;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import org.codehaus.jackson.JsonNode;
import org.junit.Test;

public class JWTAuthenticationTAITest {
    protected final String mockJWT = "eyJhbGciOiJSUzI1NiJ9.eyJpc3MiOiJhcGl0ZXN0LmRpc2NvdmVyZmluYW5jaWFsLmNvbSIsInN1YiI6Imw3eHhhZWJkODY1OWNlZmU0OWZhOGMxNTk5YTBiNWE0NTYyNyIsImV4cCI6MTU1NTAwOTY5NywiaWF0IjoxNTU1MDA4Nzk3LCJzY29wZXMiOiJQWU1UX1JNU19IRUFMVEhDSEVDSyBQWU1UX1JNUyIsImp0aSI6Ik5ERXlaV1V5TkdZdFpUazJNUzAwWkRrNExXRmpZVFV0TjJZek1EUTVObUU0Wm1Vd0xqRTFOVFV3TURrMk9UYy52eE1WeTlEc1hRcklLTS1oSlM3X1RnQ2JudlNWcTAzRE1LX09QcWE1dFdFIiwiYXVkIjoiUk1TLURFVjJFWFQiLCJvX2FwcF9jX2F0dHJzIjp7InBwbSI6IkRGUy1QYXltZW50Uk1TLURFVjJFWFQtdjEtUUEifX0.guwV-P-_7GsxXYRjiii-hXRIoB0teqdePDdXWOIqhEQ9A-RH4DT1Ek2ai8UfUSAZApltbmNJr563Y5ZP9yPc0QTTcL8N7iilTVP0Q00r7t3vuGznvtmvbDxEBhm0UlX-jPcRBMAM0rDSrrytX-kWgH7es3E_cZ_HHHdt_QGDYiyU5IuiorFjOm7Ng2_cn4n4yzlxJ_HxfweeZgcGjBWl5KTMBtqL6yXGGGDqk5tqtziYNGT89bsWHwvuI8z5nC64PQc98Qhl8_lXnz2189B6O23DUU_XYUNCWwolgwPk9H6WHssVdmqzt6qdlrq8ZE7FQR7x9KVnE7HnZJ5cJWjBmg";
    protected final String mock2 = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJTRkRDQnJpZGdlIiwic3ViIjoiMTIzNDU2Nzg5MCIsImV4cCI6MTUxNjIzOTAyMiwiaWF0IjoxNTE2MjM5MDIyLCJzY29wZXMiOiJzZmRjYnJpZGdlIiwiZW52IjoiREVWIiwiYXVkIjpbImd3c2FuZGJveC5kaXNjb3Zlci5jb20iLCJnYXRld2F5LmRpc2NvdmVyLmNvbSJdfQ.WGIzhHnX4omq0VwaIY55m6w-UVgavdwdzdZBUm4IoCM";
    protected final String mockHS512 = "eyJhbGciOiJIUzUxMiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiYWRtaW4iOnRydWUsImlhdCI6MTUxNjIzOTAyMn0.VFb0qJ1LRg_4ujbZoRMXnVkUgiuKq5KxWqNdbKq_G9Vvz-S1zZa9LPxtHWKa64zDl2ofkT8F6jBt_K4riU-fPg";
    protected final String pubKey = "MIIFsjCCBJqgAwIBAgITEgAABAN1KyhRPwEERQAAAAAEAzANBgkqhkiG9w0BAQsFADCBgjETMBEGCgmSJomT8ixkARkWA2NvbTEhMB8GCgmSJomT8ixkARkWEWRpc2NvdmVyZmluYW5jaWFsMRIwEAYKCZImiZPyLGQBGRYCcGYxFzAVBgoJkiaJk/IsZAEZFgdwcm9kZGZzMRswGQYDVQQDExJERlMgQlQgSVNTIENBIC0gRzIwHhcNMTYwOTEzMTcwOTIxWhcNMjAwOTEzMTcxOTIxWjCBjzELMAkGA1UEBhMCVVMxETAPBgNVBAgTCElMTElOT0lTMRMwEQYDVQQHEwpSaXZlcndvb2RzMRkwFwYDVQQKExBERlMgU2VydmljZXMgTExDMQ8wDQYDVQQLEwZCVCBNTVMxLDAqBgNVBAMTI2p3dGlzc3Vlci5kZXYuZGlzY292ZXJmaW5hbmNpYWwuY29tMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAzZkiq/7WtL2bms4+9SEduGdb7yEUijRGmcVxcy8ztu1eWo97MvFSjM0FLkIVgkf3c3IFyGrb+5mKuZKwvzjnnCbv3PXCWMR7GXl8iL+fpYSIYyT+zNCbtGpO7QlqGDKb7PRIWXaSmE8SE60sh2PKV2icHvFEz4/I1BoGJpAMewBKmgHYNdweNsyUp4ot/okzHp85ohOJDb7W8Ew+TWBrC87MxB3+y6i0SnsDPGkAjRLfBRHu8h+8hmwpKErb/3xVCt7HL8YQn+HMCnYNbS6013P1l895TSebkg1ednfusJtvTWd22g/q4NUMulAWM9vMM0vL2JrxCDDBMHXy6hVuNQIDAQABo4ICEDCCAgwwHQYDVR0OBBYEFJSy2gbB1mcaNCT3Hj0QTwQ4E1WuMAwGA1UdEwEB/wQCMAAwCwYDVR0PBAQDAgWgMIHpBgNVHREEgeEwgd6CIGludGFwaXNkZXYuZGlzY292ZXJmaW5hbmNpYWwuY29tgiNpbnRhcGlzZGV2bGFiLmRpc2NvdmVyZmluYW5jaWFsLmNvbYIhaW50YXBpc3Rlc3QuZGlzY292ZXJmaW5hbmNpYWwuY29tgihpbnRhcGlzdGVzdHJ3LmlsYWIuZGlzY292ZXJmaW5hbmNpYWwuY29tgiNpbnRhcGlzdGVzdG5hLmRpc2NvdmVyZmluYW5jaWFsLmNvbYIjand0aXNzdWVyLmRldi5kaXNjb3ZlcmZpbmFuY2lhbC5jb20wHwYDVR0jBBgwFoAUOmplgszlJNwb+9Ny4ag64rkQJ7MwWwYDVR0fBFQwUjBQoE6gTIZKaHR0cDovL2NybC5kaXNjb3ZlcmZpbmFuY2lhbC5jb20vQ0FWZXJpZnkvREZTJTIwQlQlMjBJU1MlMjBDQSUyMC0lMjBHMi5jcmwwZgYIKwYBBQUHAQEEWjBYMFYGCCsGAQUFBzAChkpodHRwOi8vY3JsLmRpc2NvdmVyZmluYW5jaWFsLmNvbS9DQVZlcmlmeS9ERlMlMjBCVCUyMElTUyUyMENBJTIwLSUyMEcyLmNydDANBgkqhkiG9w0BAQsFAAOCAQEAhJGDSSc/MK06LH/lPj20x36YJcaTYY7JjJjjFnr+UoeBHfANzhCTx8OBtEbOGbD8IdRpjqS+bG/EeRQcmb5vbLvxOvgRELNQFH4g1SZ59kIRLw1JRNDmZlUK5TRq0HVLvJcP1CQ553JS4PApdWgL01vbF981j3xfQPiSFFglY63hqrO0T0pHKgf6KClxkixGJ4WGc43QLhmz1dLWdlPgtZW7uWwjCFmICZwv/W9vcZ8IosEC83WZ8UGL4TFQejWEkgE7zUcORN+eSKUssqu+KcrAwaKsbcXcOJF4lhfSd8uEcBeOFojbOvUr8pHU1Dpi9GgH/8SSUxaXKlIzoCsiRw==";
    protected final String wrongKey = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDdlatRjRjogo3WojgGHFHYLugdUWAY9iR5fy4arWNA1KoS8kVw33cJibXr8bvwUAUparCwlvdbH6dvEOfou0/gCFQsHUfQrSDv+MuSUMAe8jzKE4qW+jK+xQU9a03GUnKHkkle+Q0pX/g6jXZ7r1/xAK5Do2kQ+X5xK9cipRgEKwIDAQAB";

    @Test
    public void validateTokenTest() throws Exception {
    	JsonNode claims;
        JWTValidator validator = new JWTValidator();
        claims = validator.validateToken(mockJWT, pubKey, "apisdev.discoverfinancial.com;apitest.discoverfinancial.com", "RMS-DEV2;RMS-DEV2EXT");
        assertNotNull("Verify Claims is not Null", claims);
    }

    @Test
    public void validateTokenInvalidIssuerTest() throws Exception {
    	JsonNode claims;
        JWTValidator validator = new JWTValidator();
        claims = validator.validateToken(mockJWT, pubKey, "apisdev.discoverfinancial.com-INVALID", "RMS-DEV2");
        assertNull("Verify Claims is Null for Invalid Issuer", claims);
    }

    @Test
    public void validateTokenInvalidPublicKeyTest() throws Exception {
    	JsonNode claims;
        JWTValidator validator = new JWTValidator();
        claims = validator.validateToken(mockJWT, wrongKey, "SFDCBridge", "gwsandbox.discover.com");
        assertNull("Verify Claims is Null for Invalid Key", claims);
    }

    @Test
    public void validateTokenInvalidPlanTest() throws Exception {
    	JsonNode claims;
        JWTValidator validator = new JWTValidator();
        claims = validator.validateToken(mockJWT, pubKey, "apisdev.discoverfinancial.com", "RMS-DEV2-INVALID");
        assertNull("Verify Claims is Null for incorrect Audience", claims);
    }

    @Test
    public void validateTokenInvalidAlgorithmTest() throws Exception {
    	JsonNode claims;
        JWTValidator validator = new JWTValidator();
        claims = validator.validateToken(mock2, pubKey, "apisdev.discoverfinancial.com", "RMS-DEV2");
        assertNull("Verify Claims is Null for incorrect Audience", claims);
    }
}
