package com.bp3.client.discover.sfbridge;

import java.io.UnsupportedEncodingException;
import java.security.SignatureException;
import java.security.cert.CertificateException;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.codehaus.jackson.JsonNode;

import com.ibm.websphere.security.WebTrustAssociationException;
import com.ibm.websphere.security.WebTrustAssociationFailedException;
import com.ibm.wsspi.security.tai.TAIResult;
import com.ibm.wsspi.security.tai.TrustAssociationInterceptor;

public class JWTAuthenticationTAI implements TrustAssociationInterceptor {
    private static final String CLASS_NAME = JWTAuthenticationTAI.class.getName();
    private static final String VERSION = "1.0";
    private static final String TYPE = "--- Custom Trust Assocation Interceptor --- \n Custom TAI for SF Bridge. \n"
            + CLASS_NAME;

    private static final Logger LOG = Logger.getLogger(CLASS_NAME);
    protected Map<Object, Object> sharedState;
    protected String publicKey;
    protected String expectedIssuer;
    protected String expectedAudience;
    protected String bridgeEmailHeaderName;
    protected Map<String, String> attributes;

    public JWTAuthenticationTAI() {
        super();
        sharedState = new HashMap<Object, Object>();
        LOG.fine("JWT AuthenticationTAI WAS Loaded");
    }

    @Override
    public int initialize(final Properties props) throws WebTrustAssociationFailedException {
        LOG.finer("ENTRY initialize");

        publicKey = props.getProperty("validationKey");
        expectedAudience = props.getProperty("expectedAudience");
        expectedIssuer = props.getProperty("expectedIssuer");
        bridgeEmailHeaderName = props.getProperty("BRIDGE_EMAIL_HEADER_NAME", "X-DFS_EMAIL");
        LOG.finer("Read Property - expectedIssuer = " + expectedIssuer);
        LOG.finer("Read Property - genericUsername = " + expectedAudience);
        LOG.finer("RETURN initialize");
        return 0;
    }

    public String getJWTToken(final HttpServletRequest req) {
        String authHeader = req.getHeader("Authorization");
        if (authHeader == null || authHeader.isEmpty()) {
            return null;
        }
        int spaceIndex = authHeader.indexOf(' ');
        if (spaceIndex == -1) {
            return null;
        }
        return authHeader.substring(spaceIndex + 1);
    }

    @Override
    public boolean isTargetInterceptor(final HttpServletRequest req) throws WebTrustAssociationException {
        final String jWTMsg = req.getHeader("HTTP_AUTH_TOKEN");
        LOG.finer("*********** Custom TAI - START ******************");
        //LOG.finer("EMAIL HEADER IS :"+req.getHeader(bridgeEmailHeaderName));
        //Logging all the headers in Request for debugging
        Enumeration<String> headerNames = req.getHeaderNames();
        while (headerNames.hasMoreElements()) {
			String headerName = headerNames.nextElement();
			String headerValue = req.getHeader(headerName);
			LOG.finer("Header Name: " + headerName+",Header Value: " + headerValue);
		}

        
        final boolean containsDfsEmail = req.getHeader(bridgeEmailHeaderName) != null;
        // If JWT message exists then we need to intercept.
        if (containsDfsEmail && jWTMsg != null) {
            LOG.finer("Found JWT response, will be handled it in TAI.");
            return true;
        } else if (containsDfsEmail) {
            LOG.finer("Request made without JWT, will be rejected.");
            return false;
        } else {
            LOG.finer("Bypassing Custom TAI,does not have JWT or Email Header this is not addressed.");
            LOG.finer("*********** Custom TAI - END ******************");
            return false;
        }
    }

    @Override
    public TAIResult negotiateValidateandEstablishTrust(final HttpServletRequest req, final HttpServletResponse resp)
            throws WebTrustAssociationFailedException {
        LOG.finer("ENTER negotiateValidateandEstablishTrust");
        TAIResult result = null;
        Boolean validJWT = false;
        final String jwtMsg = req.getHeader("HTTP_AUTH_TOKEN");;
        final String userEmail = req.getHeader(bridgeEmailHeaderName);
        String doAsUserID = "";
        if (jwtMsg != null) {
            validJWT = validateJWTToken(jwtMsg);
        }

        if (validJWT.equals(true)) {
            final VMMRealm v = new VMMRealm();
            doAsUserID = v.getUserId(userEmail);
            if (doAsUserID != null && doAsUserID.length() != 0) {
                // Found Valid User.This gets authenticated
                result = TAIResult.create(HttpServletResponse.SC_OK, doAsUserID);
            } else {
                // Unique User Not Found
                result = TAIResult.create(HttpServletResponse.SC_UNAUTHORIZED);
            }
        } else {
            // JWT token could not be validated";
            result = TAIResult.create(HttpServletResponse.SC_UNAUTHORIZED);
        }

        LOG.finer("*********** Custom TAI - END ******************");
        LOG.finer("RETURN negotiateValidateandEstablishTrust");
        return result;
    }

    public Boolean validateJWTToken(final String jWTMsg) throws WebTrustAssociationFailedException {
        LOG.finer("validateJWTToken");

        final JWTValidator validator = new JWTValidator();
        try {
            final JsonNode claims = validator.validateToken(jWTMsg, publicKey, expectedIssuer, expectedAudience);
            return (claims != null); // Return True is Claims is validated, else return False
        }
        catch (final IllegalStateException |UnsupportedEncodingException e) {
            throw new WebTrustAssociationFailedException("JWT Could not be Validated"+ e.getMessage());
        }
    }

    @Override
    public void cleanup() {
        sharedState = null;
    }

    @Override
    public String getType() {
        return TYPE;
    }

    @Override
    public String getVersion() {
        return VERSION;
    }
}
