package com.bp3.client.discover.sfbridge;

import java.rmi.RemoteException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.ibm.websphere.wim.SchemaConstants;
import com.ibm.websphere.wim.Service;
import com.ibm.websphere.wim.client.LocalServiceProvider;
import com.ibm.websphere.wim.exception.WIMException;
import com.ibm.websphere.wim.ras.WIMTraceHelper;
import com.ibm.websphere.wim.util.SDOHelper;

import commonj.sdo.DataObject;

public class VMMRealm {
    private static final Logger LOG = Logger.getLogger(VMMRealm.class.getName());
    private static Service service;

    static {
        service = locateService();
    }

    @SuppressWarnings("unchecked")
    public String getUserId(final String email) {
        String userId = "";
        DataObject root;
        try {
            root = SDOHelper.createRootDataObject();
            DataObject searchCtrl = SDOHelper.createControlDataObject(root, null, SchemaConstants.DO_SEARCH_CONTROL);
            searchCtrl.getList(SchemaConstants.PROP_PROPERTIES).add("sn");
            searchCtrl.getList(SchemaConstants.PROP_PROPERTIES).add("uid");
            searchCtrl.getList(SchemaConstants.PROP_PROPERTIES).add("cn");
            searchCtrl.getList(SchemaConstants.PROP_PROPERTIES).add("mail");
            searchCtrl.setString(SchemaConstants.PROP_SEARCH_EXPRESSION,
                    String.format("@xsi:type='PersonAccount' and mail='%s'", email));
            if (LOG.isLoggable(Level.INFO)) {
                LOG.info(printDO(root));
            }

            root = service.search(root);
            userId = getUserIdFromDO(root);
        } catch (RuntimeException | WIMException | RemoteException e) {
            LOG.log(Level.SEVERE, e.getMessage());
        }
        return userId;
    }

    private String getUserIdFromDO(final DataObject root) {
        List entities = root.getList(SchemaConstants.DO_ENTITIES);
        String uid = "";
        if (!entities.isEmpty() && entities.size() == 1) {
            DataObject ent = (DataObject) entities.get(0);
            uid = ent.getString("uid");
        }
        LOG.log(Level.INFO, "UID Retrieved was :{0}", uid);
        return uid;
    }

    public static void printIdentifiers(final DataObject root) throws Exception {
        List entities = root.getList(SchemaConstants.DO_ENTITIES);
        for (int i = 0; i < entities.size(); i++) {
            DataObject ent = (DataObject) entities.get(i);
            DataObject id = ent.getDataObject(SchemaConstants.DO_IDENTIFIER);
            if (id != null) {
                String uniqueName = id.getString(SchemaConstants.PROP_UNIQUE_NAME);
                LOG.log(Level.INFO, "UniqueName is {0}", uniqueName);
            } else {
                LOG.log(Level.INFO, "Missing Identifier");
            }
        }
    }

    private static Service locateService() {
        try {
            return new LocalServiceProvider(null);
        } catch (Exception e) {
            LOG.log(Level.SEVERE, e.getMessage());
        }

        return null;
    }

    public static String printDO(final DataObject obj) {
        return WIMTraceHelper.printDataObject(obj);
    }
}
