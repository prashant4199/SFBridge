package com.bp3.client.discover.sfbridge;

import java.io.UnsupportedEncodingException;
import java.util.List;
import java.util.logging.Logger;

import com.dfs.jose.key.KeyUtil;
import java.security.PublicKey;
import java.security.SignatureException;
import java.security.cert.CertificateException;

import org.codehaus.jackson.JsonNode;
import com.dfs.jose.apigateway.jwt.ApiGatewayJWTValidator;

public class JWTValidator {
	private static final Logger LOG = Logger.getLogger(JWTValidator.class.getName());

	public JsonNode validateToken(final String jwt, final String pubKey, final String expectedIssuer,
			final String expectedAudience) throws  UnsupportedEncodingException{

		try {
			final String[] expectedAudiences;
			final String[] expectedIssuers;
			PublicKey publicKey = KeyUtil.loadPublicKeyFromCertText(pubKey);
			ApiGatewayJWTValidator validator = new ApiGatewayJWTValidator(publicKey);
			validator = new ApiGatewayJWTValidator(publicKey);
			JsonNode claims = validator.validate(jwt);
			final String plan = ApiGatewayJWTValidator.getCliamField(claims, "aud").toString();
			final String issuer = ApiGatewayJWTValidator.getCliamField(claims, "iss");

			LOG.finer("Token is valid!");
			LOG.finer("Client ID: " + ApiGatewayJWTValidator.getCliamField(claims, "sub"));
			LOG.finer("Plan: " + plan);
			LOG.finer("Issuer: " + issuer);
			LOG.finer("Scopes: " + ApiGatewayJWTValidator.getCliamField(claims, "scopes"));
			LOG.finer("JWT Claims: " + claims.toString());
			
			expectedAudiences = expectedAudience.split(";");
			int count;
			for(count=0;count<expectedAudiences.length;count++) {
				if(plan.equals(expectedAudiences[count])) {
					break;
				}
			}
			if(count== expectedAudiences.length) {
				LOG.severe("Plan: "+ plan +"does not match expected plan: "+expectedAudience);
				return null;
			}
			
			expectedIssuers = expectedIssuer.split(";");
			for(count=0;count< expectedIssuers.length;count++) {
				if(issuer.equals(expectedIssuers[count])) {
					break;
				}
			}
			if(count == expectedIssuers.length) {
				LOG.severe("Issuer: "+ issuer +"does not match expected plan: "+expectedIssuer);
				return null;
			}
			
			return claims;
		}catch(final CertificateException e) {
			LOG.severe("Certificate is Invalid"+e.getMessage());
			return null;
		}catch (final SignatureException e) {
			LOG.severe("Invalid Public key supplied or expired"+e.getMessage());
			return null;
		}

	}
}
