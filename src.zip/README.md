# Discover - WebSphere Trust Association Interceptor (TAI)

This repo contains TAI built for Discover Financial Services.

For the context of this project, calls are made to BPM from Salesforce.
Salesforce is not integrated with their LDAP. So we need a TAI to authenticate
and complete tasks in BPM as Salesforce users complete them.

1. Salesforce request is intercepted by Discover API Gateway.
1. The API Gateway creates a passthrough request to BPM wrapped within JWT Header.
1. The TAI need to validate following :
    *  Verification JWT algorithm – Only RS256 is valid. Other than this should fail the authentication.
    *  JWT claim: exp – expiration time must be valid before the current system time.
    *  JWT signature must be valid
    *  JWT aud: must be valid, must ends with the value of environment in configuration setting.
    *  Uri healthcheck is not required for JWT authentication (check if a service or api still functions correctly)[mainframe will provide a healthcheck function to reports the entire status of the CICS region (will cover 99% cases)]
    *  JWT HTTP header is configurable. The default header is HTTP_AUTH_TOKEN. (not necessary for mainframe)
    *  Support secondary JWT validation key url if the primary JWT validation key url is not accessible.
    *  Able to use or not use DFS proxy for http communication (no proxy is used for mainframe to access the gateway)
    *  Able to dynamically update JWT validation key without shutdown the service. It is recommended to check the JWT validation key every 60 days by default.
    *  All of the jwt claim fields must be populated in such a way that subsequent service can obtain them, for example, via http request header. Those claim fields are: (For mainframe api, the api cannot utilize the jwt claim information. (limitation), for existing program) (for the new program, the entire jwt token can be passed to the program. A new tool can be developed to parse it for the program)
        *   iss
        *   sub
        *   exp
        *   jti
        *   aud
        *   iat
        *   Scope – scopes granted to the application
        *   o_app_c_attrs – DFS customized application attributes in json format. The content of json is defined by the service
        *   app – application name defined on the DFS api portal.
1. The TAI decrypts the message using public key provided by Discover.
1. If message is validated, TAI translates email to corresponding user ID
1. The TAI passes this message to BPM. BPM calls are completed with the userID provided from TAI.